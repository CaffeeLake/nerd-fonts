
# Nerd Fonts

This is the font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Licensing

This script has an MIT license.

The added icons' authors and licenses can be found in the `src/` subdirectory.

## Version
This archive is created from

        commit 4f133076f3c1ec224745850bdf433d4368bca07e
        Author: Fini <ulf.fini.jastrow@desy.de>
        Date:   Thu Jul 9 10:58:25 2026 +0200
        
            Merge pull request #2024 from ryanoasis/bugfix/complex_symbol_fonts
            
            Fix symbolfont handling if glyphs have multiple codepoints
