
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 3043085331f30955b336331ed92ab9588dac8957
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Wed May 8 14:19:25 2024 +0200
        
            ShareTechMono: Remove fi/fl ligs
            
            [why]
            When we crate the hard-monospaced Nerd Font Mono variant the ligs will
            be shrunk to 1 cell wide, while the content of the `fi` lig is of course
            two cells, ending up in strange overwriting issues.
            
            [how]
            Remove the `fl` and `fi` ligatures completely.
            
            Fixes: 1631
            
            Reported-by: @Markov-Komarov
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
