
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 3e0e0e033e08aeae3b42888f21d26970b586a3d0
        Author: Fini <ulf.fini.jastrow@desy.de>
        Date:   Thu Nov 14 00:39:13 2024 +0100
        
            Merge pull request #1691 from ryanoasis/feature/update-devicons
            
            Switch to devicons/devicon
